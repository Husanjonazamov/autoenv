# Autoenv

Autoenv - bu terminal orqali `.env` faylini o'qish va tahrirlashni osonlashtiradigan paket.

## O'rnatish

```bash
pip install autoenv

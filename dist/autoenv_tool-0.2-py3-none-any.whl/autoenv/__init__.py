# autoenv/__init__.py
"""
Autoenv paketining boshlang'ich moduli.
"""

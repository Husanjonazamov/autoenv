# tests/__init__.py
"""
Autoenv paketining testlari.
"""
